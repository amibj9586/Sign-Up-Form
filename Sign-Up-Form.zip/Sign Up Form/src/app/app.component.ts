import { Component, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  @ViewChild('f') signupForm: NgForm;
  countries = [
    {value: 'Argentina', viewValue: 'Argentina'},
    {value: 'Australia', viewValue: 'Australia'},
    {value: 'Austria', viewValue: 'Austria'},
    {value: 'Bangladesh', viewValue: 'Bangladesh'},
    {value: 'Brazil', viewValue: 'Brazil'},
    {value: 'China', viewValue: 'China'},
    {value: 'India', viewValue: 'India'},
    {value: 'United States', viewValue: 'United States'}
  ];
  Country;
  user = {
    fname: '',
    Surname: '',
    email: '',
    email2: '',
    Country: '',
    dob: '',
    about: '',
    companyname: '',
    industry: '',
    gender: '',
    newsletter: '',
    privacy: '',
    terms: ''
  };
  submitted = false;


  onSubmit() {
    this.submitted = true;
    this.user.fname = this.signupForm.value.userData.fname;
    this.user.Surname = this.signupForm.value.userData.Surname;
    this.user.email = this.signupForm.value.userData.email;
    this.user.email2 = this.signupForm.value.userData.email2;
    this.user.Country = this.signupForm.value.Country;
    this.user.companyname = this.signupForm.value.companyname;
    this.user.industry = this.signupForm.value.industry;
    this.user.dob = this.signupForm.value.dob;
    this.user.about = this.signupForm.value.about;
    this.user.newsletter = this.signupForm.value.newsletter;
    this.user.gender = this.signupForm.value.gender;
    this.user.privacy = this.signupForm.value.privacy;
    this.user.terms = this.signupForm.value.terms;
    console.log(this.user);
    this.signupForm.reset();
  }
}
